#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget        *objet,
                                        gpointer         user_data);
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_modifier1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_Aff_type_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonnbtroupeaux_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);
