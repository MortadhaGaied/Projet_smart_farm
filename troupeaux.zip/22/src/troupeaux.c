#ifdef HAVE_CONFIG_H
#   include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>

#include "troupeaux.h"
#include <string.h>
#include <gtk/gtk.h>
enum
{
	ETYPE,
	EID,
	ETAUX,
	EPOIDS,
	EETAT,
	EAGE,
	EPRIX,
	ECOLOR,
	
	COLUMNS
};



void ajouter_troupeau(troupeaux t)
{
	FILE *f;
	f=fopen("troupeaux.txt","a+");
	if(f!=NULL)
	{
		fprintf(f,"%s %s  %s %s %s %s %s 	%s\n",t.type,t.id,t.taux_gestation,t.poids,t.etat,t.age,t.prix,t.couleur);
	}
	fclose(f);
}


void afficher_troupeau(GtkWidget *liste,char file[50])
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char type[50];
	char id[50];
	char taux_gestation[50];
	char poids[50];
	char etat[50];
	char age[50];
	char prix[50];
	char couleur[50];

	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
		renderer =gtk_cell_renderer_text_new();
          	column =gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

		renderer =gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

		renderer =gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("taux",renderer,"text",ETAUX,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

		renderer =gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("poids",renderer,"text",EPOIDS,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

		renderer =gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("etat",renderer,"text",EETAT,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

		renderer =gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("age",renderer,"text",EAGE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

		renderer =gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

		renderer =gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("couleur",renderer,"text",ECOLOR,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

		
	}
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen(file,"r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		
		while(fscanf(f,"%s %s %s %s %s %s %s %s\n",type,id,taux_gestation,poids,etat,age,prix,couleur)!=EOF)
		{
			
			gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,ETYPE,type,EID,id,ETAUX,taux_gestation,EPOIDS,poids,EETAT,etat,EAGE,age,EPRIX,prix,ECOLOR,couleur,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}

	

}






void supprimer_troupeau(troupeaux t)
{

	char type[50];
	char id[50];
	char taux_gestation[50];
	char poids[50];
	char etat[50];
	char age[50];
	char prix[50];
	char couleur[50];

	troupeaux t2;
	FILE *f,*g;
	f=fopen("troupeaux.txt","r");
	g=fopen("tmp.txt","w");
	if(f==NULL || g==NULL)
	return;

	while(fscanf(f,"%s %s %s %s %s %s %s %s\n",t2.type,t2.id,t2.taux_gestation,t2.poids,t2.etat,t2.age,t2.prix,t2.couleur)!=EOF)
		{
			
			if(strcmp(t.type,t2.type)!=0 || strcmp(t.id,t2.id)!=0 || strcmp(t.taux_gestation,t2.taux_gestation)!=0 || strcmp(t.poids,t2.poids)!=0 || strcmp(t.etat,t2.etat)!=0 || strcmp(t.age,t2.age)!=0 || strcmp(t.prix,t2.prix)!=0 || strcmp(t.couleur,t2.couleur)!=0 )
				fprintf(g,"%s %s %s %s %s %s %s %s\n",t2.type,t2.id,t2.taux_gestation,t2.poids,t2.etat,t2.age,t2.prix,t2.couleur);
		}
	fclose(f);
	fclose(g);
	remove("troupeaux.txt");
	rename("tmp.txt","troupeaux.txt");






}
void chercher_troupeau(GtkWidget *liste,char id[50])
{
	troupeaux t;
	FILE *f,*ftmp;
	f=fopen("troupeaux.txt","r");
	ftmp=fopen("tmp.txt","w");
	while(!feof(f))
		{
			fscanf(f,"%s %s %s %s %s %s %s %s\n",t.type,t.id,t.taux_gestation,t.poids,t.etat,t.age,t.prix,t.couleur);
			if(strcmp(t.id,id)==0)
				fprintf(ftmp,"%s %s %s %s %s %s %s %s\n",t.type,t.id,t.taux_gestation,t.poids,t.etat,t.age,t.prix,t.couleur);
		}
	fclose(f);
	fclose(ftmp);
	afficher_troupeau(liste,"tmp.txt");
	remove("tmp.txt");	
	
}



void supprimer_troupeau1(char id[100])
{
	troupeaux t;
	FILE *f,*ftmp;
	f=fopen("troupeaux.txt","r");
	ftmp=fopen("tmp2.txt","w");
	while(!feof(f))
		{
			fscanf(f,"%s %s %s %s %s %s %s %s\n",t.type,t.id,t.taux_gestation,t.poids,t.etat,t.age,t.prix,t.couleur);
			if(strcmp(t.id,id)!=0)
				fprintf(ftmp,"%s %s %s %s %s %s %s %s\n",t.type,t.id,t.taux_gestation,t.poids,t.etat,t.age,t.prix,t.couleur);
		}
	fclose(ftmp);
	fclose(f);
	remove("troupeaux.txt");
	rename("tmp2.txt","troupeaux.txt");
}


int nombre_troupeau(char type[100])
{
FILE *f;
int n=0;
troupeaux t;
f=fopen("troupeaux.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",t.type,t.id,t.taux_gestation,t.poids,t.age,t.couleur,t.etat,t.prix)!=EOF ){
if(strcmp(t.type,type)==0)
n++;
}
return n;
}





