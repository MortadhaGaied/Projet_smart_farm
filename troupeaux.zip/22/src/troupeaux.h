#include <gtk/gtk.h>

typedef struct
{
char type[50];
char id[50];
char taux_gestation[50];
char poids[50];
char etat[50];
char age[50];
char prix[50];
char couleur[50];


}troupeaux;

void ajouter_troupeau(troupeaux t);
void afficher_troupeau(GtkWidget *liste,char file[50]);
void supprimer_troupeau(troupeaux t);
void chercher_troupeau(GtkWidget *liste,char id[50]);
void supprimer_troupeau1(char id[100]);

int nombre_troupeau(char type[100]);


