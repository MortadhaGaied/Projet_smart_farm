#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "troupeaux.h"
void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
troupeaux t;
GtkWidget *input1 ,*input2,*input3,*input4,*input5,*input6,*input7,*input8;
GtkWidget *Ajout;

Ajout=lookup_widget (objet,"Ajout");

input1=lookup_widget (objet,"entry1_Type");
input2=lookup_widget (objet,"entry2_ID");
input3=lookup_widget (objet,"entry3_Tauxdegestation");
input4=lookup_widget (objet,"entry4_Poids");
input5=lookup_widget (objet,"entry5_Etat");
input6=lookup_widget (objet,"entry6_Age");
input7=lookup_widget (objet,"entry7_Prix");
input8=lookup_widget (objet,"entry8_Couleur");


strcpy(t.type, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(t.id, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(t.taux_gestation, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(t.poids, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(t.etat, gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(t.age, gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(t.prix, gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(t.couleur, gtk_entry_get_text(GTK_ENTRY(input8)));


	ajouter_troupeau(t);

}


void
on_afficher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *Ajout;
GtkWidget *affiche;
GtkWidget *treeview1;

Ajout=lookup_widget (objet,"Ajout");

gtk_widget_destroy(Ajout);
affiche=lookup_widget(objet,"affiche");
affiche=create_affiche();
gtk_widget_show(affiche);
treeview1=lookup_widget (affiche,"treeview1");


afficher_troupeau(treeview1,"troupeaux.txt");
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* type;
	gchar* id;
	gchar* taux_gestation;
	gchar* poids;
	gchar* etat;
	gchar* age;
	gchar* prix;
	gchar* couleur;
	

	troupeaux t;
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&type,1,&id,2,&taux_gestation,3,&poids,4,&etat,5,&age,6,&prix,7,&couleur,-1);
		strcpy(t.type,type);
		strcpy(t.id,id);
		strcpy(t.taux_gestation,taux_gestation);
		strcpy(t.poids,poids);
		strcpy(t.etat,etat);
		strcpy(t.age,age);
		strcpy(t.prix,prix);
		strcpy(t.couleur,couleur);
		supprimer_troupeau(t);
		afficher_troupeau(treeview,"troupeaux.txt");
	}
		
	
		
}
void
on_retour_clicked                      (GtkWidget        *objet,
                                        gpointer         user_data)
{



	GtkWidget *Ajout;
	GtkWidget *affiche;
	affiche=lookup_widget(objet,"affiche");
	gtk_widget_destroy(affiche);
	Ajout=create_Ajout();
	gtk_widget_show(Ajout);
	
}







void
on_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id;
	char id1[100];
	id=lookup_widget (objet,"entry3_ID1");
	strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
	GtkWidget *affiche;
	GtkWidget *treeview1;
	affiche=lookup_widget(objet,"affiche");
	gtk_widget_destroy(affiche);
	affiche=lookup_widget(objet,"affiche");
	affiche=create_affiche();
	gtk_widget_show(affiche);
	treeview1=lookup_widget(affiche,"treeview1");
	chercher_troupeau(treeview1,id1);

}




void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[100];
FILE *f1;

GtkWidget *affiche,*id;
GtkWidget *modification;
affiche=lookup_widget(objet,"affiche");
id=lookup_widget(objet,"entry3_ID1");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
f1=fopen("tmp1.txt","w");
if (f1!=NULL)
fprintf(f1,"%s",id1);
fclose(f1);
gtk_widget_destroy(affiche);
modification=create_modification();
gtk_widget_show(modification);

}


void
on_modifier1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

FILE *f,*f1;
	GtkWidget *id,*input9,*input10;
	GtkWidget *modification;
	char id1[100];
	f1=fopen("tmp1.txt","r");
	while(!feof(f1))
	{
		fscanf(f1,"%s",id1);
	}
	fclose(f1);
	troupeaux t,t1;
	modification=lookup_widget(objet,"modification");
	f=fopen("troupeaux.txt","r");
	while(!feof(f))
		{
			fscanf(f,"%s %s %s %s %s %s %s %s\n",t.type,t.id,t.taux_gestation,t.poids,t.etat,t.age,t.prix,t.couleur);
			if(strcmp(t.id,id1)==0)
			{
				strcpy(t1.type,t.type);
				strcpy(t1.id,t.id);
				strcpy(t1.taux_gestation,t.taux_gestation);
				strcpy(t1.poids,t.poids);
				strcpy(t1.etat,t.etat);
				strcpy(t1.age,t.age);
				strcpy(t1.prix,t.prix);
				strcpy(t1.couleur,t.couleur);
				supprimer_troupeau1(id1);
			}
		}
	input9=lookup_widget (objet,"entry1_Age1");
	input10=lookup_widget (objet,"entry2_Prix1");
	strcpy(t1.age, gtk_entry_get_text(GTK_ENTRY(input9)));
	strcpy(t1.prix, gtk_entry_get_text(GTK_ENTRY(input10)));
	ajouter_troupeau(t1);
	fclose(f);



}




void
on_Aff_type_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int x;
	char ch[5],ch1[20];
	GtkWidget *labelnbtroupeaux;
	GtkWidget *nb_troupeaux;
	GtkWidget *entry1_Type;
	nb_troupeaux=lookup_widget(objet,"nb_troupeaux");
	labelnbtroupeaux=lookup_widget(objet,"labelnbtroupeaux");
	entry1_Type=lookup_widget(objet,"entry1_Type");
	strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(entry1_Type) ) );
	x=nombre_troupeau(ch1);
	sprintf(ch,"%d",x);
	gtk_label_set_text(GTK_LABEL(labelnbtroupeaux),ch);
}


void
on_buttonnbtroupeaux_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *nb_troupeaux;
	GtkWidget *affiche;
	affiche=lookup_widget(objet,"affiche");
	gtk_widget_destroy(affiche);
	nb_troupeaux=create_nb_troupeaux();
	gtk_widget_show(nb_troupeaux);
}

